<html>
    <head>
        <title>Columnis Express</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div><!DOCTYPE html>
<html lang="en"><head>

        

        


        

        <link rel="preconnect dns-prefetch" href="https://dpzl3ka2g9hpo.cloudfront.net">
        
        <link rel="preload" as="image" href="/images/static/iso-deco.svg">



        

                                                                        

        

                                                                

        

                
        

                

        

                

        

                            
        
                            
        
        


        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Page not found | ESE Servicios BIM y Transformación Digital | Uruguay</title>

        

                            
                    <meta name="robots" content="noindex">
            <meta name="googlebot" content="noindex">
        

        

        


        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="verify-v1" content="">
        <meta name="google-site-verification" content="">
        <meta name="msvalidate.01" content="">
        <meta name="generator" content="Columnis 6.0" />
        <meta name="author" content="ESE Servicios BIM y Transformación Digital | Uruguay">

        <meta name="geo.region" content="UY-MO" />
        <meta name="geo.placename" content="Montevideo" />
        <meta name="geo.position" content="-34.901754;-56.160746" />
        <meta name="ICBM" content="-34.901754, -56.160746" />

        <link rel="shortcut icon" type="image/x-icon" href="/images/favicon.png?v=2" />
        <link rel="canonical" href="https://estudioese.com.uy/not-found-14" />
        <link rel="image_src" type="image/jpeg" href="https://estudioese.com.uy/images/avatar.png" />

        <meta property="og:image" content="https://estudioese.com.uy/images/avatar.png"/>
        <meta property="og:image:width" content="1200"/>
        <meta property="og:image:height" content="630"/>
        <meta property="og:title" content="Page not found | ESE Servicios BIM y Transformación Digital | Uruguay"/>
        <meta property="og:type" content="website"/>
        <meta property="og:url" content="https://estudioese.com.uy/not-found-14"/>
        <meta property="og:site_name" content="ESE Servicios BIM y Transformación Digital | Uruguay" />
        <meta property="og:description" content="" />

                        

        

        
            
            <link href="/css/fixed.inline.css?v=1" rel="stylesheet" type="text/css">
            

            
                            <link href="/css/fixed/01-generic.screen.css?v=1" rel="stylesheet" type="text/css">
                            <link href="/css/fixed/02-components.header.css?v=1" rel="stylesheet" type="text/css">
                            <link href="/css/fixed/03-components.nav.css?v=1" rel="stylesheet" type="text/css">
                            <link href="/css/fixed/04-components.footer.css?v=1" rel="stylesheet" type="text/css">
                            <link href="/css/fixed/05-components.btns.css?v=1" rel="stylesheet" type="text/css">
                            <link href="/css/fixed/06-utilities.general.css?v=1" rel="stylesheet" type="text/css">
                            <link href="/css/404.inline.css?v=1" rel="stylesheet" type="text/css">
                            <link href="/css/404.css?v=1" rel="stylesheet" type="text/css">
            
        
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
        <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@500;600;700&amp;display=swap" rel="stylesheet">

        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>


<body><header class="c-header">
    <div class="c-header__holder">
        <div class="c-header__wrapper o-wrapper">

            <h1 class="c-header__brand">
                <a href="/" class="c-header__brand-link u-tap-size">
                    <span class="u-hidden-for-seo">ESE Servicios BIM y Transformación Digital | Uruguay</span>
                    <svg class="c-header__logo" enable-background="new 0 0 141 54" height="54" viewBox="0 0 141 54" width="141" xmlns="http://www.w3.org/2000/svg"><g fill="#1e3161"><path d="m70.9 11.2 19 9.8v-11.2l-19-9.8z" fill="#1e3161"></path><path d="m89.8 43-40.5-20.7v-11.3l40.5 20.8z" fill="#2f4d7e"></path><path d="m68.2 42.8-18.9-9.1v11.2l18.9 9.1 21.6-11v-11.2z"></path><path d="m14.3 48.8v-41.7h26.7v6.4h-19.2v10.3h17.1v6.3h-17.1v12.2h20.7v6.5z"></path><path d="m98.5 48.8v-41.7h26.8v6.4h-19.2v10.3h17.1v6.3h-17.1v12.2h20.6v6.5z"></path></g></svg>    
                </a> <!-- .c-header__brand-link -->
            </h1> <!-- .c-header__brand -->


            <button type="button" class="c-header__btn c-nav-btn js-toggleNav" title="Toggle navigation"><span class="c-nav-btn__bar"></span></button>

        </div> <!-- .c-header__wrapper -->



        <!-- NAV -->
        
        
        <div class="c-header__nav c-nav js-nav">
            <div class="c-nav__wrapper o-wrapper">
                <div class="c-nav__holder">
                    
                    
                    <nav class="c-nav__nav c-heading">
                        <h2 class="u-hidden-for-seo">Main Navigation</h2>
                        <ul class="c-nav__list">
                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                    
                                <li class="c-nav__item c-nav__delay--1">
                                    <a href="/what-we-do-2" class="c-nav__link u-tap-size">What we do</a>
                                </li>
                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                    
                                <li class="c-nav__item c-nav__delay--2">
                                    <a href="/projects-9" class="c-nav__link u-tap-size">Projects</a>
                                </li>
                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                    
                                <li class="c-nav__item c-nav__delay--3">
                                    <a href="/about-us-3" class="c-nav__link u-tap-size">About Us</a>
                                </li>
                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                    
                                <li class="c-nav__item c-nav__delay--4">
                                    <a href="/articles-6" class="c-nav__link u-tap-size">Articles</a>
                                </li>
                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                    
                                <li class="c-nav__item c-nav__delay--5">
                                    <a href="/contact-us-8" class="c-nav__link u-tap-size">Contact Us</a>
                                </li>
                                                            
                        </ul>

                    </nav> <!-- .c-nav__nav -->

                </div> <!-- .c-nav__holder -->
            </div> <!-- .c-nav__wrapper -->
        </div> <!-- .c-nav -->

    </div> <!-- .c-header__holder -->
</header> <!-- .c-header -->



<div class="o-viewport js-viewport">





    

<main>


    <!-- ! HERO -->

    <div class="c-hero o-fullscreen">
        <div class="o-hero__wrapper o-wrapper">

            <p class="c-hero__heading c-hero__heading--bold c-heading c-heading--xl">404</p>
            <h2 class="c-hero__title c-heading">The page you are looking for was not found...</h2>

        </div> <!-- .o-hero__wrapper -->
    </div> <!-- .c-hero -->



    <!-- ! PROJECTS -->

    <section class="c-projects o-wrapper o-fullscreen">
        <div class="c-404__holder">
            
            <h2 class="c-404__heading c-heading c-heading--lg">Maybe you'll be interested in this content:</h2>
            
            <h3 class="c-404__heading c-heading c-heading--strong">Projects</h3>
            
            <ul class="c-projects__list">

                                                                            <li class="c-projects__item">
                        <div class="c-projects__project c-project">

                                                        
                            <a href="/catehua-10?sid=101" class="c-project__pic-link">
                                <picture class="c-project__pic c-pic c-pic--cover">
                
            
        
                    
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/34/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/34/107_05_q90@2.webp 2x" media="(min-width: 1441px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/33/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/33/107_05_q90@2.webp 2x" media="(min-width: 1281px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/32/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/32/107_05_q90@2.webp 2x" media="(min-width: 1025px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/31/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/31/107_05_q90@2.webp 2x" media="(min-width: 980px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/30/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/30/107_05_q90@2.webp 2x" media="(min-width: 769px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/29/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/29/107_05_q90@2.webp 2x" media="(min-width: 768px)">
                                
                                                                                                                                                                                                                                                                                                                    
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/28/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/28/107_05_q90@2.webp 2x" media="(min-width: 500px) and (max-width: 767px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/27/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/27/107_05_q90@2.webp 2x" media="(min-width: 415px)">
                                
                                    
                                                                                                                    
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/26/107_05_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/128/26/107_05_q90@2.webp 2x">
                    
        
        
        
                    
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/34/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/34/107_05_q90@2.png 2x" media="(min-width: 1441px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/33/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/33/107_05_q90@2.png 2x" media="(min-width: 1281px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/32/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/32/107_05_q90@2.png 2x" media="(min-width: 1025px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/31/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/31/107_05_q90@2.png 2x" media="(min-width: 980px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/30/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/30/107_05_q90@2.png 2x" media="(min-width: 769px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/29/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/29/107_05_q90@2.png 2x" media="(min-width: 768px)">
                                
                                                                                                                                                                                                                                                                                                                    
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/28/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/28/107_05_q90@2.png 2x" media="(min-width: 500px) and (max-width: 767px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/27/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/27/107_05_q90@2.png 2x" media="(min-width: 415px)">
                                
                                    
                                                                                                                    
                        
                                                            <source type="image/png" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/128/26/107_05_q90.png, https://dpzl3ka2g9hpo.cloudfront.net/images/128/26/107_05_q90@2.png 2x">
                    
        
        
        <img src="https://dpzl3ka2g9hpo.cloudfront.net/images/128/26/107_05_q90.png" alt="Catehua" loading="lazy" class="c-pic__img">
    
                
</picture>
                            </a> <!-- .c-project__pic-link -->

                            <div class="c-project__card">

                                <h3 class="c-project__heading">
                                    <a href="/catehua-10?sid=101" tabindex="-1">Catehua</a>
                                </h3>

                                                                <p class="c-project__category">Multifmaily</p>
                                
                                <div class="c-project__bottom">
                                    <p class="c-project__location"></p>
                                    <a href="/catehua-10?sid=101" class="c-project__link u-tap-size" tabindex="-1">Read more</a>
                                </div>

                            </div> <!-- .c-project__card -->
                        </div> <!-- .c-project -->
                    </li> <!-- .c-projects__item -->
                                                                                                <li class="c-projects__item">
                        <div class="c-projects__project c-project">

                                                        
                            <a href="/more-buceo-10?sid=102" class="c-project__pic-link">
                                <picture class="c-project__pic c-pic c-pic--cover">
                
            
        
                    
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/34/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/34/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 1441px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/33/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/33/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 1281px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/32/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/32/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 1025px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/31/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/31/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 980px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/30/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/30/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 769px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/29/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/29/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 768px)">
                                
                                                                                                                                                                                                                                                                                                                    
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/28/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/28/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 500px) and (max-width: 767px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/27/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/27/304_exterior-01_mep_q90@2.webp 2x" media="(min-width: 415px)">
                                
                                    
                                                                                                                    
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/26/304_exterior-01_mep_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/131/26/304_exterior-01_mep_q90@2.webp 2x">
                    
        
        
        
                    
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/34/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/34/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 1441px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/33/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/33/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 1281px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/32/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/32/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 1025px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/31/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/31/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 980px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/30/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/30/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 769px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/29/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/29/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 768px)">
                                
                                                                                                                                                                                                                                                                                                                    
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/28/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/28/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 500px) and (max-width: 767px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/27/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/27/304_exterior-01_mep_q90@2.jpg 2x" media="(min-width: 415px)">
                                
                                    
                                                                                                                    
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/131/26/304_exterior-01_mep_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/131/26/304_exterior-01_mep_q90@2.jpg 2x">
                    
        
        
        <img src="https://dpzl3ka2g9hpo.cloudfront.net/images/131/26/304_exterior-01_mep_q90.jpg" alt="More Buceo" loading="lazy" class="c-pic__img">
    
                
</picture>
                            </a> <!-- .c-project__pic-link -->

                            <div class="c-project__card">

                                <h3 class="c-project__heading">
                                    <a href="/more-buceo-10?sid=102" tabindex="-1">More Buceo</a>
                                </h3>

                                                                <p class="c-project__category">Multifamily</p>
                                
                                <div class="c-project__bottom">
                                    <p class="c-project__location"></p>
                                    <a href="/more-buceo-10?sid=102" class="c-project__link u-tap-size" tabindex="-1">Read more</a>
                                </div>

                            </div> <!-- .c-project__card -->
                        </div> <!-- .c-project -->
                    </li> <!-- .c-projects__item -->
                                                                                                <li class="c-projects__item">
                        <div class="c-projects__project c-project">

                                                        
                            <a href="/nostrum-central-10?sid=103" class="c-project__pic-link">
                                <picture class="c-project__pic c-pic c-pic--cover">
                
            
        
                    
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/34/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/34/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 1441px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/33/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/33/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 1281px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/32/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/32/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 1025px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/31/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/31/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 980px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/30/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/30/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 769px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/29/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/29/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 768px)">
                                
                                                                                                                                                                                                                                                                                                                    
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/28/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/28/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 500px) and (max-width: 767px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/27/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/27/513_render-exterior-01_q90@2.webp 2x" media="(min-width: 415px)">
                                
                                    
                                                                                                                    
                        
                        <source type="image/webp" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/26/513_render-exterior-01_q90.webp, https://dpzl3ka2g9hpo.cloudfront.net/images/129/26/513_render-exterior-01_q90@2.webp 2x">
                    
        
        
        
                    
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/34/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/34/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 1441px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/33/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/33/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 1281px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/32/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/32/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 1025px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/31/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/31/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 980px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/30/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/30/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 769px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/29/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/29/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 768px)">
                                
                                                                                                                                                                                                                                                                                                                    
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/28/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/28/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 500px) and (max-width: 767px)">
                                
                                                                                                                                                                                                                                                            
                                                                                        
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/27/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/27/513_render-exterior-01_q90@2.jpg 2x" media="(min-width: 415px)">
                                
                                    
                                                                                                                    
                        
                                                                                                <source type="image/jpeg" srcset="https://dpzl3ka2g9hpo.cloudfront.net/images/129/26/513_render-exterior-01_q90.jpg, https://dpzl3ka2g9hpo.cloudfront.net/images/129/26/513_render-exterior-01_q90@2.jpg 2x">
                    
        
        
        <img src="https://dpzl3ka2g9hpo.cloudfront.net/images/129/26/513_render-exterior-01_q90.jpg" alt="Nostrum Central" loading="lazy" class="c-pic__img">
    
                
</picture>
                            </a> <!-- .c-project__pic-link -->

                            <div class="c-project__card">

                                <h3 class="c-project__heading">
                                    <a href="/nostrum-central-10?sid=103" tabindex="-1">Nostrum Central</a>
                                </h3>

                                                                <p class="c-project__category">Multifamily</p>
                                
                                <div class="c-project__bottom">
                                    <p class="c-project__location"></p>
                                    <a href="/nostrum-central-10?sid=103" class="c-project__link u-tap-size" tabindex="-1">Read more</a>
                                </div>

                            </div> <!-- .c-project__card -->
                        </div> <!-- .c-project -->
                    </li> <!-- .c-projects__item -->
                                    

            </ul> <!-- .c-projects__list -->
        </div> <!-- .c-404__holder -->
    </section> <!-- .c-projects -->

</main>





<!-- ! FOOTER -->

<footer class="c-footer">


    <!-- ! CTA -->

    <div class="c-footer__cta c-footer-cta o-fullscreen">
        <div class="c-footer-cta__wrapper o-wrapper">

                            <p class="c-footer-cta__heading c-heading c-heading--bold">Want to know more?</p>
            
            <div class="c-footer-cta__btns">
                                                            <a href="/how-we-work-4" class="c-footer-cta__cta c-btn u-tap-size">Discover how we work</a>
                                                                                <a href="/contact-us-8" class="c-footer-cta__cta c-btn u-tap-size">Contact Us</a>
                                                                                <a href="/contact-us-8#request" class="c-footer-cta__cta c-btn u-tap-size">Request your proposal</a>
                                    
            </div> <!-- .c-footer-cta__btns -->

        </div> <!-- .c-footer-cta__wrapper -->
    </div> <!-- .c-footer-cta -->


    <!-- FOOTER -->

    <div class="c-footer__footer">
        <div class="c-footer__wrapper o-wrapper">
            <div class="c-footer__holder">

                <nav class="c-footer__nav">
                    <h2 class="u-hidden-for-seo">Primary Navigation</h2>
                    <ul class="c-footer__list">

                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/what-we-do-2" class="c-footer__link">What we do</a>
                            </li>
                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/projects-9" class="c-footer__link">Projects</a>
                            </li>
                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/about-us-3" class="c-footer__link">About Us</a>
                            </li>
                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/articles-6" class="c-footer__link">Articles</a>
                            </li>
                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/contact-us-8" class="c-footer__link">Contact Us</a>
                            </li>
                        
                        
                    </ul> <!-- .c-footer__list -->
                </nav>
                <nav class="c-footer__nav c-footer__nav--legal">
                    <h2 class="u-hidden-for-seo">Legal Navigation</h2>
                    <ul class="c-footer__list">
                        
                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/terms-conditions-11" class="c-footer__link">Terms &amp; Conditions</a>
                            </li>
                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/privacy-policy-12" class="c-footer__link">Privacy Policy</a>
                            </li>
                                                                                                                
                                                                                                                                                                                                                                                                                
                            <li class="c-footer__item">
                                <a href="/cookies-policy-13" class="c-footer__link">Cookies Policy</a>
                            </li>
                        

                    </ul> <!-- .c-footer__list -->
                </nav>


                <nav class="c-footer__social c-footer-social">
                    <h2 class="u-hidden-for-seo">Social media</h2>
                    <ul class="c-footer-social__list">
                                                    <li class="c-footer-social__item">
                                <a href="https://www.facebook.com" class="c-footer-social__link c-footer-social__link--fb" title="Facebook" target="_blank" rel="noopener">
                                </a>
                            </li>
                                                    <li class="c-footer-social__item">
                                <a href="https://twitter.com" class="c-footer-social__link c-footer-social__link--tw" title="Twitter" target="_blank" rel="noopener">
                                </a>
                            </li>
                                                    <li class="c-footer-social__item">
                                <a href="https://instagram.com" class="c-footer-social__link c-footer-social__link--ig" title="Instagram" target="_blank" rel="noopener">
                                </a>
                            </li>
                                                    <li class="c-footer-social__item">
                                <a href="https://youtube.com" class="c-footer-social__link c-footer-social__link--yt" title="YouTube" target="_blank" rel="noopener">
                                </a>
                            </li>
                        
                    </ul> <!-- .c-footer-social__list -->
                </nav>

                <div class="c-footer__copyright">
                    <p class="c-footer__text">AXET © Copyright 2019 - 2022</p>
                    <p class="c-footer__text">
                        Web development:
                        <a href="https://www.solcre.com/" class="c-footer__dev u-tap-size" target="_blank" title="Solcre Technology Solutions" rel="noopener">Solcre</a></p>
                </div> <!-- .c-footer__copyright -->

            </div> <!-- .c-footer__holder -->
        </div> <!-- .c-footer__wrapper -->
    </div> <!-- .c-footer__footer -->

</footer>



</div> <!-- .o-viewport -->










    <script>
        var translations = JSON.parse('""').translations;
        var captchaSiteKey = '';
    </script>



            <script src="/js/fixed/interfaz.js?v=1"></script>
    


    
</body></html></div>
    </body>
</html>